

var authCred = {
    user : 'mtapia',
    password : 'm741852963',
    userCred : function() {
        return this.user;
    },
    passCred : function() {
        return this.password;
    } 

};   






